const express = require('express');
const {
    registerUser,
    loginUser,
    getUsers,
    updateUser,
    deleteUser
} = require('../controllers/userController');

const router = express.Router();

// Public routes
router.post('/', registerUser); // api/users (Create User)
router.post('/login', loginUser); // api/users/login (Login User)

// Protected routes (for a real app, these would have authentication middleware)
router.get('/', getUsers); // api/users (Get all users)
router.put('/:id', updateUser); // api/users/:id (Update a user)
router.delete('/:id', deleteUser); // api/users/:id (Delete a user)

module.exports = router;
