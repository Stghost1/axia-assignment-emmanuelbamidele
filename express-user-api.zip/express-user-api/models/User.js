const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = mongoose.Schema({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true,
        unique: true, // Ensure emails are unique
        match: [
            /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
            'Please add a valid email'
        ]
    },
    password: {
        type: String,
        required: true,
        minlength: 6 // Minimum password length
    },
    isAdmin: {
        type: Boolean,
        required: true,
        default: false // Regular users are not admins by default
    },
    hobbies: {
        type: [String], // Array of strings
        default: []
    }
}, {
    timestamps: true // Adds createdAt and updatedAt fields
});

// Hash password before saving the user
userSchema.pre('save', async function(next) {
    if (!this.isModified('password')) { // Only hash if password is new or modified
        next();
    }

    const salt = await bcrypt.genSalt(10);
    this.password = await bcrypt.hash(this.password, salt);
    next();
});

// Method to compare entered password with hashed password
userSchema.methods.matchPassword = async function(enteredPassword) {
    return await bcrypt.compare(enteredPassword, this.password);
};

const User = mongoose.model('User', userSchema);

module.exports = User;
