const User = require('../models/User');
const bcrypt = require('bcryptjs'); // Already used in model, but good for explicit clarity if needed for other password ops here

// @desc    Create a new user
// @route   POST /api/users
// @access  Public
const registerUser = async (req, res) => {
    const { name, email, password, isAdmin, hobbies } = req.body;

    try {
        const userExists = await User.findOne({ email });

        if (userExists) {
            return res.status(400).json({ message: 'User already exists' });
        }

        const user = await User.create({
            name,
            email,
            password, // Password will be hashed by the pre-save hook in the model
            isAdmin,
            hobbies
        });

        if (user) {
            res.status(201).json({
                _id: user._id,
                name: user.name,
                email: user.email,
                isAdmin: user.isAdmin,
                hobbies: user.hobbies,
                message: 'User registered successfully'
            });
        } else {
            res.status(400).json({ message: 'Invalid user data' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Auth user & get token (Login)
// @route   POST /api/users/login
// @access  Public
const loginUser = async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });

        if (user && (await user.matchPassword(password))) {
            res.json({
                _id: user._id,
                name: user.name,
                email: user.email,
                isAdmin: user.isAdmin,
                hobbies: user.hobbies,
                message: 'Logged in successfully'
                // In a real app, you'd generate a JWT token here
            });
        } else {
            res.status(401).json({ message: 'Invalid email or password' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Get all users
// @route   GET /api/users
// @access  Private/Admin (for a real app) - For this example, public for simplicity
const getUsers = async (req, res) => {
    try {
        const users = await User.find({}).select('-password'); // Exclude password from the response
        res.json(users);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Update user account
// @route   PUT /api/users/:id
// @access  Private (for a real app) - For this example, public for simplicity
const updateUser = async (req, res) => {
    const { id } = req.params;
    const { name, email, password, isAdmin, hobbies } = req.body;

    try {
        const user = await User.findById(id);

        if (user) {
            user.name = name || user.name;
            user.email = email || user.email;
            user.isAdmin = typeof isAdmin === 'boolean' ? isAdmin : user.isAdmin;
            user.hobbies = hobbies || user.hobbies;

            // Only update password if it's provided
            if (password) {
                user.password = password; // The pre-save hook will hash this
            }

            const updatedUser = await user.save(); // save() will trigger the pre-save hook for password hashing

            res.json({
                _id: updatedUser._id,
                name: updatedUser.name,
                email: updatedUser.email,
                isAdmin: updatedUser.isAdmin,
                hobbies: updatedUser.hobbies,
                message: 'User updated successfully'
            });
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// @desc    Delete user account
// @route   DELETE /api/users/:id
// @access  Private/Admin (for a real app) - For this example, public for simplicity
const deleteUser = async (req, res) => {
    const { id } = req.params;

    try {
        const user = await User.findById(id);

        if (user) {
            await user.deleteOne(); // Mongoose 6+ uses deleteOne() or deleteMany()
            res.json({ message: 'User removed' });
        } else {
            res.status(404).json({ message: 'User not found' });
        }
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

module.exports = {
    registerUser,
    loginUser,
    getUsers,
    updateUser,
    deleteUser
};
